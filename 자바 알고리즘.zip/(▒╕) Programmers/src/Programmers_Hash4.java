public class Programmers_Hash4 {
    public int[] solution(String[] genres, int[] plays) {

        
        int[] answer = {};


        return answer;
    }

    public static void main(String[] args) {
        
    }
}

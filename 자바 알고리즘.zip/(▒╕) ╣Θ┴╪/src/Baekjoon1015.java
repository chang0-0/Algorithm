import java.util.*;

public class Baekjoon1015 {

    private static int Number() {
        int result = 0;    

        return result;
    }   

    public static void main(String[] args) {
        // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        // // 띄어쓰기로 구분 하기 위해 br사용
        // int N = Integer.parseInt(br.readLine());
        // HashMap<Integer, Integer> map = new HashMap<>();
        
    
        
        //System.out.println(Arrays.toString(A));
    }
}

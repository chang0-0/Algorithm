import java.util.*;
import java.io.*;

public class Test2 {
	
	public static void main(String[] args) {
		
	} // End of main
	
    public int[] solution(int[] balance, int[][] transaction, int[] abnormal) {
        int[] answer = {};
        return answer;
    }

} // End of Main class
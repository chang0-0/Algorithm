import java.util.*;
import java.io.*;

public class Test3 {
	
	public static void main(String[] args) {
		
	} // End of main
	
    public int[] solution(String[] maze, String[] queries) {
        int[] answer = {};
        return answer;
    }

} // End of Main class
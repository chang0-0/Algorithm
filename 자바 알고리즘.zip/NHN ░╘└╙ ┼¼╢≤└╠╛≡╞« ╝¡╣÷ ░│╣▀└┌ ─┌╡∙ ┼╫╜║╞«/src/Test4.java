import java.util.*;
import java.io.*;

public class Test4 {
	
	public static void main(String[] args) {
		
	} // End of main
	
    public long solution(long[] players, int power, int k) {
        long answer = 0;
        return answer;
    }

} // End of Main class
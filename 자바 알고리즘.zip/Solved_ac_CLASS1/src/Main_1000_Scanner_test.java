import java.util.*;


public class Main_1000_Scanner_test {

	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		System.out.println(num1+num2);
	}
}

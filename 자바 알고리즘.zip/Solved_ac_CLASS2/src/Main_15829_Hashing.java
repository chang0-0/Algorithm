import java.util.*;
import java.io.*;

public class Main_15829_Hashing {
	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/input_bj_15829.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int L = Integer.parseInt(br.readLine());
		String str = br.readLine();
		
		
		
		
		
		
		
	}
}

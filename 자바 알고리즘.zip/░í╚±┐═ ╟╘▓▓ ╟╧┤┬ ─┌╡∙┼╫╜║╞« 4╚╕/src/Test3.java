import java.util.*;
import java.io.*;

public class Test3 {
	public static void main(String[] args) throws Exception  {
		System.setIn(new FileInputStream("res/test3.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
	} // End of main

} // End of Main class